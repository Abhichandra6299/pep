
#include <iostream>
using namespace std;
enum weekday{monday,tuesday,wednesday,thrusday,friday,saturday,sunday};

int main()
{
   weekday today;
   today = friday;
   
   if(today==friday){
       
   cout<<"today is friday"<<endl;
   }
   cout<<"numerical value of friday:" <<today<<endl;
   
    return 0;
}