#include<iostream>
using namespace std;

int main()
{
    int n;
    cout << "Enter number: ";
    cin >> n;

    int temp = n;
    int sum = 0;

    while(n > 0)
    {
        int last = n % 10;
        sum = sum + last * last * last;
        n = n / 10;
    }

    if(sum == temp)
        cout << "Armstrong Number";
    else
        cout << "Not Armstrong Number";

    return 0;
}