
#include <iostream>
using namespace std;

int main()
{
   float l,b,area;
   cout<<"enter l";
   cin>>l;
   cout<<"enter b";
   cin>>b;
   area = l*b;
   cout<<"area of rectangle"<<area;
   

    return 0;
}