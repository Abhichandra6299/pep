#include<iostream>
using namespace std;
int main(){
    int n;
    cout<<"enter number:"<<endl;
    cin>>n;
    int square = n*n;
    int sum = 0;
     
    while(square>0){
        sum = sum+(square % 10);
        square = square/10;
        
    } 
     if(sum==n)
        cout<<"Neon Number";
    else
        cout<<"Not Neon Number";
}
