
#include <iostream>
using namespace std;
class empployee
{
public:    
 int age;
 char name[30];
 char dept[20];
}s[5];

int main()
{
    for(int i=1;i<=3;i++){
        
    cout<<"enter age"<<endl;
    cin>>s[i].age;
     cout<<"enter name"<<endl;
    cin>>s[i].name;
     cout<<"enter dept"<<endl;
    cin>>s[i].dept;
    }
    for(int i=1;i<=3;i++){
        
    cout<<"enter age"<<s[i].age<<endl;
    cin>>s[i].age;
     cout<<"enter name"<<s[i].name<<endl;
    cin>>s[i].name;
     cout<<"enter dept"<<s[i].dept<<endl;
    cin>>s[i].dept;
    }
    return 0;
}