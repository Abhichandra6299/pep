
#include <iostream>
using namespace std;

int main(){
      for(int i=1;i<=4;i++){
          cout<<"hello abhi"<<i<<endl;
      }
    

    return 0;
}