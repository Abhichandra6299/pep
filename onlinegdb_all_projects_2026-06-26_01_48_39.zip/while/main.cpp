
#include <iostream>
using namespace std;

int main(){
      int i=1;
      while(i<=4){
          cout<<"hello abhi"<<i<<endl;
          i++;
      }
    

    return 0;
}