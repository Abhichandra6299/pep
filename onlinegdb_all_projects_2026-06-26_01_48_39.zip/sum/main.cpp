#include <iostream>
using namespace std;

int main() {
    int n;
    cin >> n;

    int sum = 0;

    for (int i = 1; i <= n; i++) {
        if (i % 2 == 0) {
            sum -= i;   
            cout << "-" << i;
        } else {
            sum += i;   
            if (i == 1)
                cout << i;
            else
                cout << "+" << i;
        }
    }

    cout << "=" << sum;

    return 0;
}