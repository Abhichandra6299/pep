#include <iostream>
using namespace std;

int main()
{
    float radius,area;
    const float pi=3.1416;
    cout<<"enter radius";
    cin>>radius;
    area=pi*radius*radius;
    cout<<"area of circle = "<<area<<end1;
    return 0;
}
   