#include <iostream>
using namespace std;

int main()
{
    int a, b, sum;
    sum = a+b;
    cout<<"enter the first number";
    cin>> a;
     cout<<"enter the second number";
    cin>> b;
    cout<<"the sum of a and b is "<<a+b;

    return 0;
}