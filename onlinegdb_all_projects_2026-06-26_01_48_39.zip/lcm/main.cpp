#include<iostream>
using namespace std;
int gcd(int a , int b){
    while(b!=0){
        int rem = a%b;
        a = b;
        b = rem;
        
    }
    return a;
}
int main(){
    int a ,b;
    cout<<"enter a and b"<<endl;
    cin>>a>>b;
    cout << "GCD = " << gcd(a, b) << endl;
    cout << "LCM = " << (a * b) / gcd(a, b);

    return 0;

}