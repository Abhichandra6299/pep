#include <iostream>
using namespace std;

class student {
public:
    static int total;   // static variable (shared among all objects)
    student() {
        total += 1;     // increment when object is created
    }
};

int student::total = 0;   // initialize static variable

int main() {
    student s1, s2, s3;   // creating 3 objects
    cout << "Number of students created: " << student::total << endl;
    return 0;
}
