
#include <iostream>
using namespace std;

int main(){
      int i=1;
     do{
          cout<<"hello abhi"<<i<<endl;
          i++;
      }
       while(i<=4);
    

    return 0;
}