
#include <iostream>
using namespace std;
struct empployee
{
 int age;
 char name[30];
 char dept[20];
}emp1;

int main()
{
    cout<<"enter age"<<endl;
    cin>>emp1.age;
     cout<<"enter name"<<endl;
    cin>>emp1.name;
     cout<<"enter dept"<<endl;
    cin>>emp1.dept;
    
    return 0;
}