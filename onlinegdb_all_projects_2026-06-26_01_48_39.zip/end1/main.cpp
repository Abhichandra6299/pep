#include<iostream>
using namespace std;

int main()
{
     const int a = 34;
    cout<<"the value of a was " <<a<<end1;
    a = 45;
    cout<<"the value of a was " <<a<<end1;
    return 0;
}