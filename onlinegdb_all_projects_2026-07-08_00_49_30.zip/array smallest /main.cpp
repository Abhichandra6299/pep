
#include <iostream>
#include <climits>
using namespace std;

int main()
{
    int size;
    cout<<"enter the size of array"<<endl;
    cin>>size;
    int arr[size];
    cout<<"enter "<<size<<"elements"<<endl;
    for(int i=0;i<size;i++){
        cin>>arr[i];
    }
    int smallest = INT_MAX;
    for(int i=0; i<size; i++){
        if(arr[i]<smallest){
            smallest = arr[i];
        }
    }
    cout<<"smallest="<<smallest<<endl;
    return 0;
}