
#include <iostream>
using namespace std;

int findsum(int arr[], int size)
{ 
    int sum = 0;
    for(int i=0;i<size;i++){
        sum = sum+arr[i];
        
    }
    return sum;
}
    int main()
    {
        int size = 0;
        cout<<"enter size of array:";
        cin>>size;
        int array[size];
        cout<<"enter"<<size<<"element";
        for(int i=0;i<size;i++){
            cin>>array[i];
            
        }
        cout << "Sum = " << findsum(array, size) << endl;
    
    return 0;
}