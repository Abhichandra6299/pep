
#include <iostream>
using namespace std;

int main()
{
    int size;
    cout<<"enter size of array:";
    cin>>size;
    int arr[size];
    cout<<"enter"<<size<<"elements"<<endl;
    
    for(int i=0;i<size;i++)
{
    cin>>arr[i];
}
    int min=0;
    int max=0;
    for(int i=0;i<size;i++){
        if(arr[i]>arr[max])
        max = i;
        
    if(arr[i]<arr[min])
        min = i;
    
}
swap(arr[max],arr[min]);
cout<<"after swap max and min";
for(int i=0;i<size;i++){
    cout<<arr[i]<<" ";
    
}

    return 0;
}