
#include <iostream>
using namespace std;

int main()
{
    int size;
    cout<<"enter size of array:";
    cin>>size;
    int array[size];
    cout<<"enter"<<size<<"elements:";
    for(int i=0;i<size;i++){
        cin>>array[i];
    }
    int start =0;
    int end = size-1;
    while(start<end){
        swap(array[start],array[end]);
            start++;
            end--;
        }
    
    cout<<"reversed array ";
    
    for(int i=0; i<size; i++){

        cout<<array[i]<<" ";  

}
return 0;
}